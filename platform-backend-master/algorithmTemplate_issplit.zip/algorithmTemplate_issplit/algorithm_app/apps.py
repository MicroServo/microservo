from django.apps import AppConfig


class AlgorithmAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'algorithm_app'
